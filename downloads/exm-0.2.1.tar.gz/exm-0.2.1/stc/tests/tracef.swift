#include "builtins.swift"

// SKIP-THIS-TEST

tracef("%s", "hi");
