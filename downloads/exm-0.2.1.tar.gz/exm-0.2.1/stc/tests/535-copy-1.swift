#include "builtins.swift"


main {
    int x = 1;
    int y = x;
    float a = 12.3;
    float b = a;
    string i = "hello";
    string j = i;

    trace(y, b, j);
}
