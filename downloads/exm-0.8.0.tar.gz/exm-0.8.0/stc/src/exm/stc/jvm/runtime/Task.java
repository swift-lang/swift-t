package exm.stc.jvm.runtime;

/**
 * Task interface.  Idea is currently to implement as closure
 */
public interface Task {
  public void run();
}
