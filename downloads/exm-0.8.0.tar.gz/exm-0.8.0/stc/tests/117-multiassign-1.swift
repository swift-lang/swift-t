

main {

    int a; int b; int c;


    int x; int y; int z;

    a, b, c = 1, 2, 3;
    trace(a, b, c);

    (x, y, z) = c+1, b+1, a+1;
    trace(x, y, z);

}
