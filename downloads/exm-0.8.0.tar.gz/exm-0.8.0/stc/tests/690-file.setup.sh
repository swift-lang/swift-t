echo "hello world!" > ./alice.txt
