#!/usr/bin/env bash
dir=$1
mkdir -p $dir
echo "TEST" > $dir/tmp.txt
