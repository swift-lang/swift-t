This is a source distribution of Swift/T.

Documentation, including installation instructions, can be found
in the docs subdirectory.
