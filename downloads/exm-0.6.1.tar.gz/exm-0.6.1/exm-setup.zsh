#!/bin/zsh

# Installs ExM release

# To control this script, edit exm-settings.zsh

# Locate release directory (location of this script)
RELEASE=$( cd $( dirname $0 ) ; /bin/pwd )
declare RELEASE

# Load some shell functions, including @() function
source ${RELEASE}/turbine/scripts/helpers.zsh
if [[ ${?} != 0 ]]
then
  print "Could not find installation files!"
  return 1
fi

cd ${RELEASE}
exitcode

# Read user settings
source exm-settings.sh
exitcode

# Link user settings into build directory for scripts
pushd build
if [ ! -e exm-settings.sh ]
then
  ln -s ../exm-settings.sh ./exm-settings.sh
  exitcode
fi
popd

# Diagnose some common issues before starting
# TODO: necessary?
if [ -z "$MPICC" ]
then
  which mpicc > /dev/null
  exitcode "Could not find mpicc!"
elif [ ! -x "$MPICC" ]
then
  echo "mpicc $MPICC not found or not executable"
  exit 1
fi
print

# Override build behaviour
export RUN_AUTOTOOLS=0
export CONFIGURE=1
export MAKE_CLEAN=0
export SVN_UPDATE=0

print "Compile and install c-utils..."
pushd c-utils
exitcode
${RELEASE}/build/cutils-build.sh
exitcode "exm-setup.zsh: c-utils: build FAILED"
popd
print

print "Compile ADLB..."
pushd lb
exitcode
${RELEASE}/build/lb-build.sh
exitcode "exm-setup.zsh: lb: build FAILED"
popd
print

print "Compile and install Turbine..."
pushd turbine
exitcode
${RELEASE}/build/turbine-build.sh
exitcode "exm-setup.zsh: turbine: build FAILED"
popd
print

print "Compile STC..."
pushd stc
exitcode
${RELEASE}/build/stc-build.sh
exitcode "exm-setup.zsh: stc: build FAILED"
popd
print
