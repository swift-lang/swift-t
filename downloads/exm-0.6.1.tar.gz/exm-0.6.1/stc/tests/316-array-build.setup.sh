#!/bin/sh

echo "INPUT DATA" > input.txt 

