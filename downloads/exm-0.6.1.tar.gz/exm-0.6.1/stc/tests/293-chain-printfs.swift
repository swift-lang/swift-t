
import io;

main
{
  printf("p1") => printf("p2");
}
