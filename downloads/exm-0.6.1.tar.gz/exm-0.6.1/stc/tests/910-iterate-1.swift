
main {
    iterate i {
        trace(i);
    } until (i >= 10)
}
