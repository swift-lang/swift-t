#!/bin/sh

rm test-316-*.data
