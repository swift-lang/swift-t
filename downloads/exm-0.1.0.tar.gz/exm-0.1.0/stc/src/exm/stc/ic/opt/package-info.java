/**
 * This package contains all of the optimisation passes applied to the
 * intermediate code.  ICOptimiser is the entry point which applies
 * all of the passes to an IC tree
 */
package exm.stc.ic.opt;
