/**
 * This package provides the command line interface, and orchestrates the
 * other components of the compiler.
 */
package exm.stc.ui;
