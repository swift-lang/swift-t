package exm.stc.tclbackend;

class TclFunRef {
  public final String pkg;
  public final String symbol;
  public TclFunRef(String pkg, String symbol) {
    super();
    this.pkg = pkg;
    this.symbol = symbol;
  }
}