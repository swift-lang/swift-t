/**
 * This package contains utilities and other things shared between different 
 * modules of the compiler
 */
package exm.stc.common;
