/**
 * Definitions of custom exceptions thrown by the compiler 
 */
package exm.stc.common.exceptions;
