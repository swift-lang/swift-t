/**
 * Utility classes including custom data structures
 */
package exm.stc.common.util;
