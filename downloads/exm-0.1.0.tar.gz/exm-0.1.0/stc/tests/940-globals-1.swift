#include <builtins.swift>


global const int MY_INT = 2;
global const string MY_S = "hello world";
global const boolean MY_B = false;
global const float MY_F = 3.14;
global const float MY_NEG = -3.14;


main {
    trace(MY_INT, MY_S, MY_B, MY_F, MY_NEG);

}
