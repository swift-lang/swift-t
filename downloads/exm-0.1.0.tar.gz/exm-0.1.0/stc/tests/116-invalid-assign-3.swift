#include "builtins.swift"
//THIS-TEST-SHOULD-NOT-COMPILE

(int r) f (int x) {
    int k;
    k = k;
    r = k;
}
