#include <builtins.swift>

main {

    foreach x, i in [15:30] {
        trace(i, x);
    }
}
