

main () {

}

// THIS-TEST-SHOULD-NOT-COMPILE
// - no varargs in composite function
(int r) f (...) {

}
