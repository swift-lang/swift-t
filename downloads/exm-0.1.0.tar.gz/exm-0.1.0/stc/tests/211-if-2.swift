#include "builtins.swift"

main
{
  int a;
  a = 1;

  int d;
  if (a)
  {
    int b;
    b = 1;
    d = b + 1;
  } else {
    
    int c;
    c = 2;
    d = c;
  }
  trace(d);
}
