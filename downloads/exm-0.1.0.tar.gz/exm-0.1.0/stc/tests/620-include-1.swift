#include "builtins.swift"

#include "header-620.swift"

main{}
