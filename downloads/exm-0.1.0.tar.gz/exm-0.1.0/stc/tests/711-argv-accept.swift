
#include <builtins.swift>
#include <io.swift>
#include <sys.swift>

// THIS-TEST-SHOULD-NOT-RUN

main {
  argv_accept("v");
}
