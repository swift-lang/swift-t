

main () {

}

// THIS-TEST-SHOULD-NOT-COMPILE
// - no varargs in return value
(...) f(int x) "turbine" "0.0.2" "f";
