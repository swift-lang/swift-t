#!/bin/bash

# Clean up test suite outputs

rm -f *.tcl
rm -f *.ic
rm -f *.out
rm -f *.stc.*

exit 0
