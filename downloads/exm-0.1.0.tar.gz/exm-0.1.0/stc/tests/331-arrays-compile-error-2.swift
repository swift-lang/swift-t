#include "builtins.swift"
//THIS-TEST-SHOULD-NOT-COMPILE

main {
    int A[] = 1;
}

