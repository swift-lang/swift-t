
# Inspect/edit this file before installing ExM software

# Installation location
EXM_PREFIX=/tmp/exm-install

# MPI locations
EXM_MPI=${HOME}/sfw/mpich2-trunk
EXM_MPICC=${EXM_MPI}/bin/mpicc

# make -j setting (1 is just fine)
MAKE_J=1

# We look for Tcl in PATH
# User may override Tcl here:
EXM_TCL=$( cd $( dirname $( dirname $( which tclsh ) ) ) ; /bin/pwd )
