/* adlb_conf.h.  Generated from adlb_conf.h.in by configure.  */
/* adlb_conf.h.in.  Generated from configure.in by autoheader.  */

/* Define if Fortran names are lowercase */
/* #undef F77_NAME_LOWER */

/* Define if Fortran names containing an underscore have two trailing
   underscores */
/* #undef F77_NAME_LOWER_2USCORE */

/* Define if Fortran names are lowercase with a trailing underscore */
/* #undef F77_NAME_LOWER_USCORE */

/* Define if Fortran names preserve the original case */
/* #undef F77_NAME_MIXED */

/* Define if Fortran names preserve the original case and add a trailing
   underscore */
/* #undef F77_NAME_MIXED_USCORE */

/* Define if Fortran names are uppercase */
/* #undef F77_NAME_UPPER */

/* Define if long long allowed */
/* #undef HAVE_LONG_LONG */

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT ""

/* Define to the full name of this package. */
#define PACKAGE_NAME ""

/* Define to the full name and version of this package. */
#define PACKAGE_STRING ""

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME ""

/* Define to the version of this package. */
#define PACKAGE_VERSION ""

/* Define calling convention */
/* #undef STDCALL */
