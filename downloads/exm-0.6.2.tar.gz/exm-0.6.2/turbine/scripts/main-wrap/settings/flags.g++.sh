
# Flags for G++

# C only
STD="-std=gnu99"
# C and C++:
PIC=-fPIC
SHARED=-shared
