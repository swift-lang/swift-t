import io;
import sys;

// THIS-TEST-SHOULD-NOT-RUN
main {
  // Should only accept decimals
  int N = toint("0x1232");
  trace(N);
}
