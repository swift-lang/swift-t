#include "builtins.swift"

// Will be plus
(int o) p(int i1, int i2) "turbine" "0.0.1" "plus";

main {}
