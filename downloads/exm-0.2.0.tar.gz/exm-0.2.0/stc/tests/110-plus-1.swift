#include "builtins.swift"

main
{
  int x;
  int y;
  int z;

  x = 1;
  y = 2;

  (z) = x + y;
}
