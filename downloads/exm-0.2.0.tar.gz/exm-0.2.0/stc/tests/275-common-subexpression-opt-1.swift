#include <builtins.swift>

main  {
    foreach i in [1:10] {
        trace(i+1);
        trace(i+1);
    }
}
