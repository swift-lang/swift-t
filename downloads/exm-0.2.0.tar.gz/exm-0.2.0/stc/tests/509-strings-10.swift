#include <builtins.swift>
//THIS-TEST-SHOULD-NOT-COMPILE

main {
  string s = "hi";
  int A[];
  A[s] = 3;
}
