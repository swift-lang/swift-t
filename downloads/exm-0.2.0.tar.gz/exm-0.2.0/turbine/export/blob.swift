/*
 * Copyright 2013 University of Chicago and Argonne National Laboratory
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License
 */
#ifndef BLOB_SWIFT
#define BLOB_SWIFT

@pure
(int o) blob_size(blob b) "turbine" "0.0.6" "blob_size_async"
   [ "set <<o>> [ turbine::blob_size <<b>> ]" ] ;

@pure
(blob o)   blob_null() "turbine" "0.0.2" "blob_null"
 [ "set <<o>> [ turbine::blob_null ]" ];
@pure
(blob o)   blob_from_string(string s) "turbine" "0.0.2" "blob_from_string"
 [ "set <<o>> [ adlb::blob_from_string <<s>> ]" ];
@pure
(string o) string_from_blob(blob b) "turbine" "0.0.2" "string_from_blob";
@pure
(blob o) blob_from_floats(float f[]) "turbine" "0.0.2" "blob_from_floats";
@pure
(float f[]) floats_from_blob(blob b) "turbine" "0.0.2" "floats_from_blob";

#endif // BLOB_SWIFT
