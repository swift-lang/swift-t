
/*
 * tcl-julia.h
 *
 *  Created on: Jun 2, 2014
 *      Author: wozniak
 */

#ifndef TCL_JULIA_H
#define TCL_JULIA_H

void tcl_julia_init(Tcl_Interp* interp);

#endif
