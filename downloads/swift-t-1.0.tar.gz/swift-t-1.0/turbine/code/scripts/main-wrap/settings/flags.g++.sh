
# Flags for G++

STD=
PIC=-fPIC
SHARED=-shared
