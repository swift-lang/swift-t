rm outfile
