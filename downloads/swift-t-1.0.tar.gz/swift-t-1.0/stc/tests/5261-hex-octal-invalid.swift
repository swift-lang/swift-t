
// THIS-TEST-SHOULD-NOT-COMPILE
main {
  trace(0x123G);
}
