// THIS-TEST-SHOULD-NOT-COMPILE
main {
   int A[string];
   A["1"] = 1;

   trace(A[1]);
}
