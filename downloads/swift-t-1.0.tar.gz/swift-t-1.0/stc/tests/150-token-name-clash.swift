
// exposes problem with name clashes

main {

 int declare_variable = 0;
 int program = 0;

}
