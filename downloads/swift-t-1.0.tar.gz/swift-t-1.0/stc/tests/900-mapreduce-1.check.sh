rm -r 900-data
