//THIS-TEST-SHOULD-NOT-COMPILE

int k;
k = k;
r = k;
