/*
 * Copyright 2013 University of Chicago and Argonne National Laboratory
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License
 */
package exm.stc.ic.opt;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;

import exm.stc.common.Logging;
import exm.stc.common.Settings;
import exm.stc.common.exceptions.InvalidOptionException;
import exm.stc.common.lang.Arg;
import exm.stc.common.lang.Operators;
import exm.stc.common.lang.Operators.BuiltinOpcode;
import exm.stc.common.lang.Types;
import exm.stc.common.lang.Var;
import exm.stc.common.util.HierarchicalMap;
import exm.stc.common.util.Pair;
import exm.stc.ic.ICUtil;
import exm.stc.ic.tree.Conditionals.Conditional;
import exm.stc.ic.tree.ICContinuations.Continuation;
import exm.stc.ic.tree.ICInstructions;
import exm.stc.ic.tree.ICInstructions.Builtin;
import exm.stc.ic.tree.ICInstructions.Instruction;
import exm.stc.ic.tree.ICInstructions.Opcode;
import exm.stc.ic.tree.ICTree.Block;
import exm.stc.ic.tree.ICTree.Function;
import exm.stc.ic.tree.ICTree.Program;
import exm.stc.ic.tree.ICTree.Statement;
import exm.stc.ic.tree.ICTree.StatementType;

/**
 * This module contains a set of optimisations that either seek out or
 * consolidate constant values in a Swift-IC function 
 *
 */
public class ConstantFold implements OptimizerPass {

  @Override
  public String getPassName() {
    return "Constant folding";
  }

  @Override
  public String getConfigEnabledKey() {
    return Settings.OPT_CONSTANT_FOLD;
  }

  /**
   * Perform constant folding and propagations on the program
   * NOTE: we assume that all variable names in a function are unique,
   * so the makeVarNamesUnique pass should be performed first
   * @param logger
   * @param in
   * @throws InvalidOptionException
   */
  @Override
  public void optimize(Logger logger, Program in) throws InvalidOptionException {
    HierarchicalMap<Var, Arg> globalConsts =  new HierarchicalMap<Var, Arg>();
    // Populate global constants
    for (Var global: in.getGlobalVars()) {
      Arg constVal = in.lookupGlobalConst(global.name());
      globalConsts.put(global, constVal);
    }
    
    for (Function f: in.getFunctions()) {
      // Set of variables that should not be replaced
      Set<Var> blacklist = new HashSet<Var>();
      constantFold(logger, in, f, f.mainBlock(), blacklist, 
                   globalConsts.makeChildMap());
    }
  }

  /**
   * Perform constant folding and propagation on a block and all of its children
   * @param logger
   * @param block
   * @param varMap variables known from outer scope
   * @return true if change made
   * @throws InvalidOptionException 
   */
  private static boolean constantFold(Logger logger, Program prog, 
      Function fn, Block block, Set<Var> blacklist,
      HierarchicalMap<Var, Arg> knownConstants) throws InvalidOptionException {
    // Find all constants in block
    findBlockConstants(logger, fn, block, blacklist, knownConstants,
                       false, false);
    
    boolean changed = false;
    boolean converged = false;
    while (!converged) {
      converged = true; // assume no changes
      // iterate over instructions in this block, find instructions which 
      //      take only constants as inputs 
      ListIterator<Statement> it = block.statementIterator();
      while (it.hasNext()) {
        Statement stmt = it.next();
        if (stmt.type() == StatementType.CONDITIONAL) {
          Conditional cond = stmt.conditional();
          Block predicted = cond.branchPredict(knownConstants);
          if (predicted != null) {
            it.remove();
            cond.inlineInto(block, predicted, it);
          }
        } else {
          assert(stmt.type() == StatementType.INSTRUCTION);
          
          Pair<Boolean, Boolean> res = foldInstruction(logger, fn,
                        block, knownConstants, it, stmt.instruction());
          
          changed = changed || res.val1;
          converged = converged && res.val2;
        }
      }
      
      
      for (Continuation c: block.allComplexStatements()) {
        boolean updated = c.constantReplace(knownConstants);
        converged = converged && !updated;
        changed = changed || updated;
      }
      if (!converged) {
        logger.debug("Didn't converge, doing another constant folding pass");
      }
    }
    
    
    // Do it recursively on all child blocks.  We do this after doing the outer
    // block because more constants will have been propagated into inner block, 
    // enabled more folding
    for (Continuation c: block.allComplexStatements()) {
      for (Block b: c.getBlocks()) {
        // Make copy of constant map so that binds don't get mixed up
        boolean changedRec = constantFold(logger, prog, fn, b,
                      blacklist, knownConstants.makeChildMap());
        changed = changed || changedRec;
      }
    }
  
    // Eliminate variables (only those which were declared in this block) 
    // where possible (this will catch unneeded variables created by 
    // constant folding but also some previously unneeded ones)
    if (Settings.getBoolean(Settings.OPT_DEAD_CODE_ELIM)) {
      branchPredict(block, knownConstants);
    }
    return changed;
  }

  private static Pair<Boolean, Boolean> foldInstruction(Logger logger,
      Function fn, Block block, HierarchicalMap<Var, Arg> knownConstants,
      ListIterator<Statement> it, Instruction inst) {
    boolean converged = true, changed = false;

    if (logger.isDebugEnabled()) {
      logger.debug("Candidate instruction for constant folding: " 
                                          + inst.toString());
    }
    Map<Var, Arg> newConsts = inst.constantFold(fn.getName(),
                                        knownConstants);
    
    if (newConsts == null) {
      logger.debug("Couldn't constant fold");
      
      Instruction newInst = inst.constantReplace(knownConstants);
      if (newInst != null) {
        newInst.setParent(block);
        it.set(newInst);
        changed = true;
      }
    } else {
      if (logger.isDebugEnabled()) {
        logger.debug("Can replace instruction " + inst.toString() + 
                                              " with constant: " + newConsts);
      }
      converged = false;
      changed = true;
      knownConstants.putAll(newConsts);
      // replace with multiple set instructions
      ArrayList<Instruction> replacements = 
                new ArrayList<Instruction>(newConsts.size());
      
      for (Entry<Var, Arg> newConst: newConsts.entrySet()) {              
        Var var = newConst.getKey();
        Arg newVal = newConst.getValue();
        logger.debug("New constant: " + var);
        if (Types.isScalarFuture(var.type())) {
          replacements.add(ICInstructions.futureSet(var, newVal));
        } else {
          assert(Types.isScalarValue(var.type()));
          replacements.add(ICInstructions.valueSet(var, newVal));
        }
      }
      ICUtil.replaceInsts(block, it, replacements);
    }
    return Pair.create(changed, converged);
  }

  /**
   * Find all the directly assigned constants in the block
   * @param logger
   * @param block
   * @param blacklist variables that should not be replaced (e.g. if double-assigned)
   * @param knownConstants
   * @param onlyDefinedInBlock if true, only include constants defined
   *                           in this block
   */
  static void findBlockConstants(Logger logger, 
      Function fn, Block block,
      Set<Var> blacklist,
      Map<Var, Arg> knownConstants,
      boolean ignoreLocalValConstants,
      boolean onlyDefinedInBlock) {
    Set<Var> defs = null;
    if (onlyDefinedInBlock) {
      defs = new HashSet<Var>(block.getVariables());
    }
    
    ListIterator<Statement> it = block.statementIterator();
    while (it.hasNext()) {
      Statement stmt = it.next();
      if (stmt.type() == StatementType.INSTRUCTION) {
        Instruction inst = stmt.instruction();
        if (isValueStoreInst(inst, ignoreLocalValConstants)) {
          Var var = inst.getOutput(0);
          if (!blacklist.contains(var) && 
              (!onlyDefinedInBlock || defs.contains(var))) {
            Arg value = inst.getInput(0);
            logger.debug("Found constant " + var + " = " + value);
            Arg oldValue = knownConstants.get(var);
            if (oldValue != null && !value.equals(oldValue)) {
              // TODO: cut down on number of duplicate warning messages
              Logging.uniqueWarn("Invalid code detected during optimization. "
                  + "Conflicting values for " + var + " = " + value +
                    " != " + oldValue + " in " + fn.getName() + ".\n" +
                    "This may have been caused by a double-write to a variable. " +
                    "Please look at any previous warnings emitted by compiler. " +
                    "Otherwise this could indicate a stc bug");
              blacklist.add(var);
              // TODO: hack
              if (knownConstants instanceof HierarchicalMap) {
                ((HierarchicalMap<Var, Arg>)knownConstants).remove(var, false);
              } else {
                knownConstants.remove(var);
              }
              // blacklist variable to avoid being replaced
              blacklist.add(var);
            } else {
              knownConstants.put(var, value);
            }
          }
        }
      }
    }
  }

  /**
   * Return true if this instruction assigns a constant value to
   * a variable
   * @param inst
   * @param ignoreLocalValConstants
   * @return
   */
  public static boolean isValueStoreInst(Instruction inst,
      boolean ignoreLocalValConstants) {
    if (inst.getInputs().size() == 0) {
      return false;
    }
    
    Arg input = inst.getInput(0);
    if (input.isConstant()) {
      if (inst.op == Opcode.STORE_INT || inst.op == Opcode.STORE_BOOL            
          || inst.op == Opcode.STORE_FLOAT || inst.op == Opcode.STORE_STRING
          || inst.op == Opcode.STORE_BLOB || inst.op == Opcode.STORE_VOID) {
        return true;
      } else if (!ignoreLocalValConstants && inst.op == Opcode.LOCAL_OP) {
        BuiltinOpcode op = ((Builtin)inst).subop;
        return (Operators.isCopy(op));
      }
    }
    return false;
  }

  static private class Predicted {
    final Continuation cont;
    final Block block;
    private Predicted(Continuation cont, Block block) {
      super();
      this.cont = cont;
      this.block = block;
    }
  }
  
  /**
   * Predict which way a branch will go based on known values of variables
   * in the program
   * @param block
   * @param knownConstants
   */
  private static void branchPredict(Block block,
      HierarchicalMap<Var, Arg> knownConstants) {
    // Use list to preserve order
    List<Predicted> predictedBranches = new ArrayList<Predicted>();
    ListIterator<Continuation> it = block.continuationIterator();
    while (it.hasNext()) {
      Continuation c = it.next();
      if (c.isNoop()) {
        it.remove();
        continue;
      }
      // With constants, we might be able to predict branches
      Block branch = c.branchPredict(knownConstants);
      if (branch != null) {
        predictedBranches.add(new Predicted(c, branch));
      }
    }
    for (Predicted p: predictedBranches) {
      p.cont.inlineInto(block, p.block);
    }
  }
}
