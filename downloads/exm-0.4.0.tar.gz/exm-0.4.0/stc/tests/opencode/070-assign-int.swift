int i;

i = 2;
