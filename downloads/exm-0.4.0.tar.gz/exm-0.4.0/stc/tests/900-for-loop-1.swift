
main {
    for (int i = 0, int j = 1; i < 10; i = i + 1, j = j * 2) {
        trace(i, j);
    }
}
