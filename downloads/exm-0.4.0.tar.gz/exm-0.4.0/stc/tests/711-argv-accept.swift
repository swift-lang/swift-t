
import io;
import sys;

// THIS-TEST-SHOULD-NOT-RUN

main {
  argv_accept("v");
}
