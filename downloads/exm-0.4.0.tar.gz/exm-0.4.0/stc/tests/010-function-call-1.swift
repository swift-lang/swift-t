
(int output) func(int a, int b)
{
  int i;
  int j;
  (output) = a + b;
}

main
{
  int d;
}
