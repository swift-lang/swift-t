/*
  Define common types used in c-utils
 */

#ifndef __CUTILS_TYPES_H
#define __CUTILS_TYPES_H

// Type used for long integer keys/values
typedef long long cutil_long;


#endif // __CUTILS_TYPES_H
