#!/bin/sh
set -eu

rm 566.txt
