// THIS-TEST-SHOULD-NOT-CAUSE-WARNING
// Shouldn't raise errors if globals unread

int x = 10;
