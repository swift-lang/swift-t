echo "INPUT DATA" > input.txt 

