
// THIS-TEST-SHOULD-NOT-COMPILE
main {
   float A[notype];
}
