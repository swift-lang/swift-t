
// THIS-TEST-SHOULD-NOT-COMPILE
main {
  (int x) f (int y) {
    x = y;
  }
}
