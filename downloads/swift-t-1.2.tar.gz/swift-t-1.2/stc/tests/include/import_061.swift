
float a_variable = 1.0;
