// Create temporaries
trace(1 + 2 * 3 / 4);
