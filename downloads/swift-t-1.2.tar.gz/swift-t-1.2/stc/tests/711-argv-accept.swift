
import io;
import sys;

// THIS-TEST-SHOULD-NOT-RUN

argv_accept("v");
