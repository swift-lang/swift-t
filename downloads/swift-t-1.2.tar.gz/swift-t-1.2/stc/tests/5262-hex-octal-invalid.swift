// THIS-TEST-SHOULD-NOT-COMPILE
main {
  int x = 0o9132;
}
