
// THIS-TEST-SHOULD-NOT-COMPILE
// Ensure clean output - no stack trace

F(int i, file f1) "mr2" "0.0" [ "puts ohai" ];
F(int i, file f1) "mr2" "0.0" [ "puts ohai" ];

main {}
