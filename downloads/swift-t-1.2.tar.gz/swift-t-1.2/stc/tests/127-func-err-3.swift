

main () {

}

// THIS-TEST-SHOULD-NOT-COMPILE
// - no varargs in return value
(int ...x) f () {

}
