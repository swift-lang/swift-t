
// Tests error handling: erroneous brackets in array definition

// THIS-TEST-SHOULD-NOT-COMPILE

// Output argument should be (string result[])
(string[] result) f(string inp) "nothing" "0.0.0" "f";

main{}
