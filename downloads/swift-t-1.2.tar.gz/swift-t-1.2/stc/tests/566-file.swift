import files;

main {
  foreach i in [1:3] {
    file f<"566.txt"> = write("test");
  }
}
