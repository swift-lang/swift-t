// THIS-TEST-SHOULD-NOT-COMPILE

main {
  // Non-matching args
  x = (1, 2);
}
