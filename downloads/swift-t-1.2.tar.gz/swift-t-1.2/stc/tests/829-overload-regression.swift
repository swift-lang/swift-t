import assert;

//THIS-TEST-SHOULD-NOT-COMPILE
assertEqual(1, 1);
