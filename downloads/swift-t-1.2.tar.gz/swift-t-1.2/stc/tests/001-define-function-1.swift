
(int output) func(int a, int b)
{
  // UNSET-VARIABLE-EXPECTED
  int i;
  int j;
  output = 0;
}

main
{
  int a;
}
