// THIS-TEST-SHOULD-NOT-COMPILE
// Not allowed to have varargs with optional

f(int x=0, int ...more) {

}
