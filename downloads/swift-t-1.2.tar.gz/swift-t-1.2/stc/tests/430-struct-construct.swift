type mystruct {
  int x;
  int y[];
}


S = mystruct(1, [1,2,3]);
