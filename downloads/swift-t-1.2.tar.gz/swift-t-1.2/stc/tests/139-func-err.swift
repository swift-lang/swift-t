
// THIS-TEST-SHOULD-NOT-COMPILE
main {

  typedef int test;
}
