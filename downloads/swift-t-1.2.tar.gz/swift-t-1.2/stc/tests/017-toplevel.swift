import io;

/* Check support for top-level code */

string name = "Juan";
printf("HELLO %s", name);
