
app () f (file inp, string s, int i) {
    "cat" @inp;
}

main {
    file x = input_file("630-helloworld.txt");
    f(x, "Bob", 1);
}
