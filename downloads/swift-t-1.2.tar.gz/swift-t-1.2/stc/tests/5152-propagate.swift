
import files;
import io;

void o = make_void();
void w = make_void();
int  i = 3+4;

void a = propagate(o,w,i);
a => printf("OK");
