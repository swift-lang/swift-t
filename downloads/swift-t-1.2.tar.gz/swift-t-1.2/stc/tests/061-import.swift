import include.import_061;

// Regression test for global variable declarations - issue #784
// COMPILE-ONLY-TEST

trace(a_variable);
