
// Check relationship operators on strings

import assert;

main {
    assert("hello" == "hello", "hello != hello");
    assert("hello" != "goodbye", "hello == goodbye");
}
