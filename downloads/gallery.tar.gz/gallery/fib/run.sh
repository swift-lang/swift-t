#!/bin/sh -e
swift-t fib.swift -n=7
