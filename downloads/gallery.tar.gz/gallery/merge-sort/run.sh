#!/bin/sh
swift-t merge.swift
