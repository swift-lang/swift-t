#!/bin/sh
rm -fv sorted.txt
rm -fv data-*.txt
