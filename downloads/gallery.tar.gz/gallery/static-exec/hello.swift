import io;
printf("HELLO");
