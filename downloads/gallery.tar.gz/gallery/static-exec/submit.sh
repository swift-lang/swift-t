#!/bin/bash

turbine -m pbs -n 4 -x ./hello.x
