#!/bin/sh -e

rm -fv out-*.txt mtc.octal assembled.txt
