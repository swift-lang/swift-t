#!/bin/zsh

# Installs ExM release

# To control this script, edit exm-settings.zsh

# Locate release directory (location of this script)
RELEASE=$( cd $( dirname $0 ) ; /bin/pwd )
declare RELEASE

# Load some shell functions, including @() function
source ${RELEASE}/turbine/scripts/helpers.zsh
if [[ ${?} != 0 ]]
then
  print "Could not find installation files!"
  return 1
fi

cd ${RELEASE}
exitcode

# Read user settings
source exm-settings.sh
exitcode

# Link user settings into build directory for scripts
pushd build
if [ ! -e exm-settings.sh ]
then
  ln -s ../exm-settings.sh ./exm-settings.sh
  exitcode
fi
popd

# Diagnose some common issues before starting
if [ ! -x "${CC}" ]
then
  which "${CC}" > /dev/null
  exitcode "Could not find CC compiler specified: ${CC}!"
fi
print

# Override build behaviour
export RUN_AUTOTOOLS=0
export CONFIGURE=1
export MAKE_CLEAN=0
export SVN_UPDATE=0

if [ -d coaster-c-client ]
then
  print "Compile and install coaster-c-client..."

  if [ -z "$COASTER_INSTALL" ]
  then
    # Should be set by default
    COASTER_INSTALL=${EXM_PREFIX}/coaster-c-client
  fi

  export COASTER_INSTALL

  pushd coaster-c-client
  exitcode
  ${RELEASE}/build/coaster-c-client-build.sh
  exitcode "exm-setup.zsh: coaster-c-client: build FAILED"
  popd
  print
fi

if [ -d swift-k ]
then
  print "Install swift-k..."

  if [ -z "$SWIFTK_INSTALL" ]
  then
    # Should be set by default
    SWIFTK_INSTALL="${EXM_PREFIX}/swift-k"
  fi

  export SWIFTK_INSTALL

  mkdir -p "${SWIFTK_INSTALL}"
  cp -r swift-k/* "${SWIFTK_INSTALL}"
  exitcode "exm-setup.zsh: installing swift-k FAILED"
fi

print "Compile and install c-utils..."
pushd c-utils
exitcode
${RELEASE}/build/cutils-build.sh
exitcode "exm-setup.zsh: c-utils: build FAILED"
popd
print

print "Compile ADLB..."
pushd lb
exitcode
${RELEASE}/build/lb-build.sh
exitcode "exm-setup.zsh: lb: build FAILED"
popd
print

print "Compile and install Turbine..."
pushd turbine
exitcode
${RELEASE}/build/turbine-build.sh
exitcode "exm-setup.zsh: turbine: build FAILED"
popd
print

print "Compile STC..."
pushd stc
exitcode
${RELEASE}/build/stc-build.sh
exitcode "exm-setup.zsh: stc: build FAILED"
popd
print
