package exm.stc.common.util;

/**
 * Simulate output arguments - useful hack
 */
public class Out <T> {
  public T val = null;
}
