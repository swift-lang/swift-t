#!/bin/zsh

# Installs ExM release

# To control this script, edit exm-settings.zsh

# Locate release directory (location of this script)
RELEASE=$( cd $( dirname $0 ) ; /bin/pwd )
declare RELEASE

source ${RELEASE}/turbine/scripts/helpers.zsh
if [[ ${?} != 0 ]]
then
  print "Could not find installation files!"
  return 1
fi

cd ${RELEASE}
exitcode

# Read user settings
source exm-settings.zsh
exitcode

if [ -z "$EXM_MPICC" ]
then
  which mpicc > /dev/null
  exitcode "Could not find mpicc!"
elif [ ! -x "$EXM_MPICC" ]
then
  echo "mpicc $EXM_MPICC not found or not executable"
  exit 1
fi

print "Compile and install c-utils..."
pushd c-utils
./configure --config-cache                         \
    --prefix=${EXM_PREFIX}/c-utils --enable-shared
exitcode
make -j ${MAKE_J}
exitcode "exm-setup.zsh: c-utils: make FAILED"
make install
exitcode
popd
print

print "Compile ADLB..."
pushd lb
exitcode
FORCE_MPI_2=""
[[ ${MPI_VERSION} == 2 ]] && FORCE_MPI_2=--enable-mpi-2
./configure --config-cache               \
    CC=${EXM_MPICC}                      \
    --prefix=${EXM_PREFIX}/lb            \
    --with-c-utils=${EXM_PREFIX}/c-utils \
    ${FORCE_MPI_2}
exitcode
make -j ${MAKE_J} install
exitcode
[[   -f lib/libadlb.so    ]] || \
  [[ -f lib/libadlb.dylib ]]
exitcode "ADLB was not compiled!"
[[   -f ${EXM_PREFIX}/lb/lib/libadlb.so    ]] || \
  [[ -f ${EXM_PREFIX}/lb/lib/libadlb.dylib ]]
exitcode "ADLB was not installed!"
popd
print

print "Compile and install Turbine..."
pushd turbine

[[ ! -z ${EXM_TCL_VERSION} ]] && TCL_VERSION=--with-tcl-version=${EXM_TCL_VERSION}
[[ ! -z ${EXM_CUSTOM_MPI} ]] && ENABLE_CUSTOM_MPI=--enable-custom-mpi
./configure --config-cache               \
    --prefix=${EXM_PREFIX}/turbine       \
    --with-tcl=${EXM_TCL}                \
    --with-mpi=${EXM_MPI}                \
    --with-c-utils=${EXM_PREFIX}/c-utils \
    --with-adlb=${EXM_PREFIX}/lb         \
    ${ENABLE_CUSTOM_MPI} ${TCL_VERSION}
exitcode
make -j ${MAKE_J} install
exitcode "exm-setup.zsh: turbine: make FAILED"
[[   -f lib/libtclturbine.so    ]] || \
  [[ -f lib/libtclturbine.dylib ]]
exitcode "Turbine was not compiled!"
[[ -f ${EXM_PREFIX}/turbine/install.txt ]]
exitcode "Turbine was not installed!"
popd
print

print "Compile STC..."
pushd stc
ant -Ddist.dir=${EXM_PREFIX}/stc         \
    -Dturbine.home=${EXM_PREFIX}/turbine \
    install
exitcode
popd
print
