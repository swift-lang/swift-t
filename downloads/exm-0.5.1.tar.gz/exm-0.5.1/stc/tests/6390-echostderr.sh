#!/usr/bin/env bash
# echo to stderr instead of stdout for testing
echo "$@" >&2
