
(int r) f (string x) {
    r = 1;
    trace(x);
}

main {
    string x = "hello world\n";
    f(x);
}
