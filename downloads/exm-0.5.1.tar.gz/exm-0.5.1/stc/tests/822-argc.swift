
import sys;

// THIS-TEST-SHOULD-NOT-COMPILE
main {
  int x = argc + 1;
}
