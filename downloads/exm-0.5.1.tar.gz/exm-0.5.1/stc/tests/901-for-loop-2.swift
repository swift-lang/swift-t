
main {
    for (int i = 0; i < 10; i = i + 1) {
        trace(i);
    }
}
