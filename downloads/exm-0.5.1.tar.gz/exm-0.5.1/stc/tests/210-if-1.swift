
main
{
  int a;
  a = 1;

  if (a)
  {
    int b;
    b = 1;
    trace(b);
  }
}
