
// Tests error handling: make sure warning output is clean

main {
  int i;
}
