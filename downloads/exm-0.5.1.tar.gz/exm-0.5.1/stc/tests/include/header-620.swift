// To be imported with preprocessing on


// (int o) q(int i1, int i2) "headerpackage" "3.3.2" "hpf";

#define INVALID_SYNTAX

(int o) t (int i) {
  int g;

  // Check preprocessor runs
  INVALID_SYNTAX

  o = 0;
}
