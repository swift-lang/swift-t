// To be imported with preprocessing off


# invalid preprocessor directive to check preprocessor not on


# Should not do recursive import
import include.module_620;

(int o) u (int i) {
  o = 0;
}
