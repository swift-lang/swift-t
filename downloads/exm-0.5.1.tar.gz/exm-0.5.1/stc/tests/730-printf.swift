
import io;

main {
  int i = 14;
  float pi = 3.1415;
  string hello = "hello";
  string format = "%i, %0.2f, %s\nnextline";
  printf(format, i, pi, hello);
}
