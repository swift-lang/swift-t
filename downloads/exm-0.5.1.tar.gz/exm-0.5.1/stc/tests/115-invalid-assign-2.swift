//THIS-TEST-SHOULD-NOT-COMPILE

(int r) f (int x) {
    int k = 2;
    k = x + 1;
    r = k + 1;
}
