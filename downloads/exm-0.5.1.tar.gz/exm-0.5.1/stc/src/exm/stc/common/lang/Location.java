package exm.stc.common.lang;

/**
 * Locations
 *
 */
public class Location {
  // This is Turbine's code for ANY_LOCATION
  public static final int ANY_LOCATION_VAL = -100;
  public static final Arg ANY_LOCATION = Arg.createIntLit(ANY_LOCATION_VAL);
}
