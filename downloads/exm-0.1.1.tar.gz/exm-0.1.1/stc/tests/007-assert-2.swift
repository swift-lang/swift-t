
// THIS-TEST-SHOULD-NOT-RUN
// check that asserts fail as expected

#include <builtins.swift>
#include <assert.swift>

main {
    assert(false, "false"); // should fail
}
