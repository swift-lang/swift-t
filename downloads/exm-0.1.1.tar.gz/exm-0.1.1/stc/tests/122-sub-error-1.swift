#include "builtins.swift"
// THIS-TEST-SHOULD-NOT-COMPILE

main {
    f();
}
