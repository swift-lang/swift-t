#include "builtins.swift"

main
{
  int a;
  int b;
  int c;
  a = 2;
  b = 1;

  (c) = a - b;

  trace(c);
}
