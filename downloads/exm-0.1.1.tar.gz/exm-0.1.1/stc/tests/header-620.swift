
// SKIP-THIS-TEST : it is a header

// (int o) q(int i1, int i2) "headerpackage" "3.3.2" "hpf";

() t (int i) {
  int g;
}
