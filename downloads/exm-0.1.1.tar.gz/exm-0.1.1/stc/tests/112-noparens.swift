#include "builtins.swift"
(int a, int b) f(int i, int j)
{
    a = 2;
    b = 3;
}

main
{
  int x;
  int y;
  int z;
  int q;

  x = 1;
  y = 2;

  z, q = f(x,y);
}

