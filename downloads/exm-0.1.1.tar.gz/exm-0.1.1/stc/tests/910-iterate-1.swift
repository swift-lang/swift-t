#include <builtins.swift>

main {
    iterate i {
        trace(i);
    } until (i >= 10)
}
