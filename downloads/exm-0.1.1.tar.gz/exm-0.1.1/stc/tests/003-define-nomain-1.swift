#include "builtins.swift"
//THIS-TEST-SHOULD-NOT-COMPILE
// because there is no main function
(int output) func(int a, int b)
{
  int i;
  int j;
  output = 0;
}

