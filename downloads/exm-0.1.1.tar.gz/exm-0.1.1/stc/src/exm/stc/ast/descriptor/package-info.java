/**
 * These descriptors are helper classes used to extract and contain 
 * information about language constructs from the Swift AST. 
 */
package exm.stc.ast.descriptor;
