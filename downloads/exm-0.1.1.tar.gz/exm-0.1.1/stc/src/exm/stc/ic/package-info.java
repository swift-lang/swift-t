/**
 * This package contains all of the middle-end of the compiler, including the
 * intermediate representation (under the tree subpackage) and the optimization
 * passes (under the opt subpackage)
 */
package exm.stc.ic;
