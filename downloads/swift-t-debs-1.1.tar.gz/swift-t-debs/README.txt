
To install the Swift/T Debian packages, run ./install-debs.sh