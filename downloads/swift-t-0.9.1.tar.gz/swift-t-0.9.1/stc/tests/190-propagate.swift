
int i = 3;
void v = propagate(i);
