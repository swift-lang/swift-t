// THIS-TEST-SHOULD-NOT-COMPILE
// Invalid escape code
s = "hello\#fail";
