#!/bin/sh 

rm A.hdf

