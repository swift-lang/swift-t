
(int ret) notmain (int input)
{
  int a;
  a = 1;

  {
    int b;
    b = 1;
  }

  {
    int b;
    b = 1;
  }
  ret = 0;
}

main
{
  int k;
}
