// Test include works

#include "header-620.swift"

main{}
