
// SKIP-THIS-TEST

tracef("%s", "hi");
