
main {
  // Regression test for bug where 1 can be interpreted as float or int
  if (1) {
    trace("hello");
  }
}
