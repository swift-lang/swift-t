
// Test noop statements
// Regression test for #207


main
{
  ;
}
