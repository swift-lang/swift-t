#!/usr/bin/env bash
# create files
touch jumped over the lazy dog
