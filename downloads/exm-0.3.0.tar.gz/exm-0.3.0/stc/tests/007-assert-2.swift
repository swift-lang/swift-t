
// THIS-TEST-SHOULD-NOT-RUN
// check that asserts fail as expected

import assert;

main {
    assert(false, "false"); // should fail
}
