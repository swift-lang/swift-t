#!/bin/sh

# Remove generated files
rm -f *.o *.x *.so adlb.clog2 *.data
rm -f test-mvm.tcl pkgIndex.tcl mvm_wrap.c
rm -f FortFuncs.cpp FortFuncs.h FortranMatrix.h FortWrap.h
rm -f FortFuncs_wrap.cxx InterfaceDefs.h
