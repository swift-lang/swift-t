#!/bin/sh

swift-t -r $PWD test-mvm.swift
