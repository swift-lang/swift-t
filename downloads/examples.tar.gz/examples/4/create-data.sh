> turbine-write-doubles A.data 1 2 3
