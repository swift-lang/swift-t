swig -module g g.h
