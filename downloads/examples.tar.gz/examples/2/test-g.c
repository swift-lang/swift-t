
#include "g.h"

main()
{
  g(2, 3);
}
