> time ./g.x
g: 2+3=5
sleeping for 5 seconds...
./g.x  0.00s user 0.00s system 0% cpu 5.003 total
