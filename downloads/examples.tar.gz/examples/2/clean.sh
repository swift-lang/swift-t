#!/bin/sh

# Remove generated files
rm -fv *.o *.x *.so adlb.clog2 *.tic
rm -fv test-g-1.tcl test-g-n.tcl pkgIndex.tcl g_wrap.c
