> export TCLLIBPATH=$PWD
> tclsh test-g.tcl
g: 2+3=5
sleeping for 5 seconds...

