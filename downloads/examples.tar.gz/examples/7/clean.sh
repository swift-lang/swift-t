#!/bin/sh

rm -fv test-f.tcl pkgIndex.tcl
