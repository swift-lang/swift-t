import io;

(int o) f(int i1, int i2) "my_pkg" "0.0" "f";

int x = 2;
int y = 3;
int z = f(x,y);
printf("sum: %i", z);
