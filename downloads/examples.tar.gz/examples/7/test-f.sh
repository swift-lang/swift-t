#!/bin/sh

swift-t -r $PWD test-f.swift
