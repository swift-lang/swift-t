import io;

mainapp;

printf("Swift...");
string A[] = [ "arg1", "arg2", "arg3" ];
rc = main_leaf(A);
printf("exit code: %i", rc);
