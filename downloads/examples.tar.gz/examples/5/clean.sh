#!/bin/sh -e

rm -f main_leaf.* extension.*
rm -f make-package.tcl pkgIndex.tcl
rm -f *.tic *.o *.so *.x
rm -f user-code.swift
