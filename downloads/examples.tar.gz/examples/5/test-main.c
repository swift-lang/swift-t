#include "main_wrap.h"
int main(int argc, char* argv[]) {
  main_leaf(argc, argv);
  return 0;
}
