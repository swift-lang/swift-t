genleaf -vv main.c main.h test-main.swift
swift-t -r $PWD user-code.swift
