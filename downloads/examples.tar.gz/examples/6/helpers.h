
double* malloc_double(void);

void print_double(double* d);

void free_double(double* d);
