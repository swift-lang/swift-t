make
swift-t -r $PWD prog-swift.swift
