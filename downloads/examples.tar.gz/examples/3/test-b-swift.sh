> stc test-b.swift test-b.tcl
> turbine test-b.tcl
length: 4
sum: 16.000000
sum (swift): 16.000000

