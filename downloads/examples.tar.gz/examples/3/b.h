
double* b(double* v, int length);
