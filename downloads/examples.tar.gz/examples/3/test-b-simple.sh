> stc test-b-simple.swift test-b-simple.tcl
> turbine test-b-simple.tcl
size(v) = 4
v[last]=10.00
v[0]=1.00
