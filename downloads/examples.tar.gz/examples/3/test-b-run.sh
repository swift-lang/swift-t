> ./b.x
length: 4
sum: 16.000000
