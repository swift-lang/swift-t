#!/bin/sh

# Remove generated files
rm -f input.data
rm -f *.o *.x *.so *.tic adlb.clog2
rm -f test-b.tcl test-b-simple.tcl pkgIndex.tcl b_wrap.c
