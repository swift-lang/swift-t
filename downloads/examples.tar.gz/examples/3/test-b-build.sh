gcc -c b.c
gcc -c test-b.c
gcc -o b.x test-b.o b.o
