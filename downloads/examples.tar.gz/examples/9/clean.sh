#!/bin/sh

rm -fv *.o *.x
rm -fv test-f.tcl
