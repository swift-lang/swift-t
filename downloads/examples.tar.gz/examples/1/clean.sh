#!/bin/sh

rm -fv pkgIndex.tcl
rm -fv test-f.tcl

