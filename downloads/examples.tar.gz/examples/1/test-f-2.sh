$ export TCLLIBPATH=$PWD
$ tclsh test-f-2.tcl
5
