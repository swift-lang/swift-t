$ tclsh make-package.tcl > pkgIndex.tcl
