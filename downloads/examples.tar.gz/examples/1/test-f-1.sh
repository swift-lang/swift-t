$ tclsh test-f-1.tcl
5
