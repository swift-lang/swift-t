$ stc -r $PWD test-f.swift test-f.tcl
$ turbine test-f.tcl
sum: 5
