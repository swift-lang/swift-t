import io;
import f;

int x = 2;
int y = 3;
int z = f(x,y);
printf("sum: %i", z);
