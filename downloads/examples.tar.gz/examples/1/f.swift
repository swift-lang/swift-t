(int o) f(int i1, int i2) "my_pkg" "0.0"
[ "set <<o>> [ my_pkg::f <<i1>> <<i2>> ]" ];
