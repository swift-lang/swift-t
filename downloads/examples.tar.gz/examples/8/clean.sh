#!/bin/sh

rm -fv *.so *.o *snip*.c *.tic
rm -fv pkgIndex.tcl
rm -fv test-f.tcl f_wrap.c
