
double f(MPI_Comm comm, int k);
