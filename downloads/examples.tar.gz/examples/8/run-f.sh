> turbine -n 4 test-f.tcl
z: -0.959
