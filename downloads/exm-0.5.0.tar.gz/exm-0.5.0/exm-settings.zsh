
# Inspect/edit this file before installing ExM software

# Installation location
EXM_PREFIX=/tmp/exm-install

# MPI locations
EXM_MPI=${HOME}/sfw/mpich-master
EXM_MPICC=${EXM_MPI}/bin/mpicc

# MPI customization (uncomment to enable)
#EXM_CUSTOM_MPI=1

# Additional flags to pass to C compiler
#export CFLAGS=
#export LDFLAGS=

# make -j setting (1 is just fine)
MAKE_J=1

# Set MPI version
# (version 3 required for parallel tasks but version 2 is also allowed)
MPI_VERSION=3

# We look for Tcl in PATH
# User may override Tcl here:
EXM_TCL=$( cd $( dirname $( dirname $( which tclsh ) ) ) ; /bin/pwd )
#Optionally specify separate Tcl library directory
#EXM_TCL_LIB=
EXM_TCL_VERSION=8.6
