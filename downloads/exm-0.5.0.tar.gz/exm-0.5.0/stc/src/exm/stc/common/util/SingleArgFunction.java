package exm.stc.common.util;

public interface SingleArgFunction<T> {
  public void call(T arg);
}
