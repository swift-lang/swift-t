#!/bin/sh -e

grep s:bc:d:a:e:f:g ${TURBINE_OUTPUT}
