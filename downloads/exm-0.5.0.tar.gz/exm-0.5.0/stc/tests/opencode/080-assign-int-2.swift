
int i;
int j;
# i = 2+2; not in swift-0
# j = i; not in swift-0
