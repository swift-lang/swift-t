
// exposes problem with name clashes

main {

 int declare_variable;
 int program;

}
