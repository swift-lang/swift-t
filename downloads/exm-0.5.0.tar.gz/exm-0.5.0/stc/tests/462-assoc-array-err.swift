// THIS-TEST-SHOULD-NOT-COMPILE
main {
   A[1] = 1;
   A["2"] = 2;
}
