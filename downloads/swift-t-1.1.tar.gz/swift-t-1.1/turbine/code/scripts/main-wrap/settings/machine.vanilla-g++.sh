
# VANILLA

TURBINE_HOME=$( cd $GENLEAF_HOME/../.. ; /bin/pwd )
source $TURBINE_HOME/scripts/turbine-build-config.sh

CC=g++
STC=stc

source $GENLEAF_HOME/settings/flags.g++.sh
