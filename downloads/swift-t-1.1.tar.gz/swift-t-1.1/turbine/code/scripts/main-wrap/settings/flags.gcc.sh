
# Flags for GCC

STD="-std=gnu99"
PIC=-fPIC
SHARED=-shared
