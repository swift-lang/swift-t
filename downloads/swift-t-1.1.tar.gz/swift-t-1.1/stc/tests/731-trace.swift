
main
{
  int a;
  int b;
  a = 2;
  b = 1;

  trace(a,b);
}
