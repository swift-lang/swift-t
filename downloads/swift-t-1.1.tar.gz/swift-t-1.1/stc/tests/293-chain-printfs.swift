
import io;

printf("p1") => printf("p2");
