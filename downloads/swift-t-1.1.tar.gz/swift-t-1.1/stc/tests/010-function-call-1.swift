
(int output) func(int a, int b)
{
  // UNSET-VARIABLE-EXPECTED
  int i;
  int j;
  (output) = a + b;
}

main
{
  int d;
}
