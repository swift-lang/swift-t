//THIS-TEST-SHOULD-NOT-COMPILE

type t {
    int a;
    int b;
}

main {
    t.a = 1;
    t.b = 2;
    trace(t.c);
}
