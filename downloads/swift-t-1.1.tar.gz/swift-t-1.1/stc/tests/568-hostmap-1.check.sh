#!/bin/sh
set -e

rm tmp.txt
