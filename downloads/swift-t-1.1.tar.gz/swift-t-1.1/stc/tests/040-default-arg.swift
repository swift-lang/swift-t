import io;

f(string m, int x = 1) {
  printf("%s: %i", m, x); 
}

f("provided", 2);
f("not provided");
