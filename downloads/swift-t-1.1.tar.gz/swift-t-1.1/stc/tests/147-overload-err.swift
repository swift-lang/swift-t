// THIS-TEST-SHOULD-NOT-COMPILE


f(int x) {

}

f(float x) {

}


// Invalid usage of function
trace(f);
