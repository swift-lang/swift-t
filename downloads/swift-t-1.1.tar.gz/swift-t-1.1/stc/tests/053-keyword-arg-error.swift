// THIS-TEST-SHOULD-NOT-COMPILE
// Not allowed to have optional before required

f(int x=0, int y) {

}

