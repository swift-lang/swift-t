

main {
  foreach x in [0:0.5:1.0] {
    trace("x",x);
  }
}
