
import sys;

// THIS-TEST-SHOULD-NOT-COMPILE
int x = argc + 1;
