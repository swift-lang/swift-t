// THIS-TEST-SHOULD-NOT-COMPILE

main {
  // Tuple as function arg
  trace((1,2,3));
}
